package com.pandaos.launcher

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * Starts PandaOS after the TV finishes booting, if the firmware delivers the boot broadcast
 * and allows apps to open a screen from the background. Nothing is forced: if Android or
 * Xiaomi blocks it, PandaOS simply starts when HOME is pressed or when it is the default launcher.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val a = intent.action
        if (a != Intent.ACTION_BOOT_COMPLETED && a != "android.intent.action.QUICKBOOT_POWERON") return
        try {
            Store.init(context)
            if (!Store.autoStart) return
            val i = Intent(context, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            context.startActivity(i)
        } catch (e: Exception) {
        }
    }
}
