package com.pandaos.launcher

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.util.TypedValue
import android.view.View
import android.widget.TextView

object Ui {
    val FACES = arrayOf("sans-serif-light", "serif", "sans-serif-condensed")
    val FACE_NAMES = arrayOf("Light sans", "Serif", "Condensed")
    val FOCUS = floatArrayOf(1.08f, 1.18f, 1.3f)
    val SPEED = longArrayOf(120L, 220L, 380L)
    val SCALE = floatArrayOf(0.9f, 1f, 1.15f)

    fun dp(c: Context, v: Int): Int = (v * c.resources.displayMetrics.density + 0.5f).toInt()

    fun alpha(color: Int, a: Int): Int = (color and 0x00FFFFFF) or (a shl 24)

    fun blend(a: Int, b: Int, t: Float): Int {
        val r = (Color.red(a) + (Color.red(b) - Color.red(a)) * t).toInt()
        val g = (Color.green(a) + (Color.green(b) - Color.green(a)) * t).toInt()
        val bl = (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t).toInt()
        return Color.rgb(r, g, bl)
    }

    fun round(color: Int, radius: Float, stroke: Int = 0, strokeW: Int = 0): GradientDrawable {
        val d = GradientDrawable()
        d.setColor(color)
        d.cornerRadius = radius
        if (strokeW > 0) d.setStroke(strokeW, stroke)
        return d
    }

    fun text(c: Context, s: String, sp: Float, color: Int, face: String = "sans-serif"): TextView {
        val t = TextView(c)
        t.text = s
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        t.setTextColor(color)
        t.typeface = Typeface.create(face, Typeface.NORMAL)
        return t
    }

    /** Makes a view focusable with a smooth scale + accent outline. */
    fun focusable(
        v: View, pal: Pal, p: Profile, radiusDp: Int = 18, cap: Float = 9f,
        onFocus: ((Boolean) -> Unit)? = null
    ) {
        val ctx = v.context
        v.isFocusable = true
        v.isClickable = true
        val r = dp(ctx, radiusDp).toFloat()
        val stroke = dp(ctx, 2)
        val anim = p.animations && !p.perf
        val s = minOf(FOCUS[p.focusScale.coerceIn(0, 2)], cap)
        val d = SPEED[p.speed.coerceIn(0, 2)]
        v.setOnFocusChangeListener { view, has ->
            view.background = if (has) round(alpha(pal.accent, 46), r, pal.accent, stroke) else null
            val t = if (has) s else 1f
            if (anim) view.animate().scaleX(t).scaleY(t).setDuration(d).start()
            else { view.scaleX = t; view.scaleY = t }
            onFocus?.invoke(has)
        }
    }
}
