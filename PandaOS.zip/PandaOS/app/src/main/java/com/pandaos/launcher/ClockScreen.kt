package com.pandaos.launcher

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.service.dreams.DreamService
import android.util.TypedValue
import android.view.Gravity
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextClock

object ClockScreen {
    fun build(ctx: Context, color: Int): FrameLayout {
        val f = FrameLayout(ctx)
        f.setBackgroundColor(Color.BLACK)
        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER_HORIZONTAL
        val clock = TextClock(ctx)
        clock.format12Hour = "h:mm"
        clock.format24Hour = "HH:mm"
        clock.setTextSize(TypedValue.COMPLEX_UNIT_SP, 150f)
        clock.setTextColor(color)
        clock.typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        clock.includeFontPadding = false
        col.addView(clock)
        val date = TextClock(ctx)
        date.format12Hour = "EEEE, d MMMM"
        date.format24Hour = "EEEE, d MMMM"
        date.setTextSize(TypedValue.COMPLEX_UNIT_SP, 26f)
        date.setTextColor(Ui.alpha(color, 150))
        date.letterSpacing = 0.08f
        col.addView(date)
        f.addView(col, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))
        return f
    }
}

/** Real Android screensaver (DreamService). Activate it in Android's screen saver settings. */
class PandaDream : DreamService() {
    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        isInteractive = false
        isFullscreen = true
        setContentView(ClockScreen.build(this, Color.parseColor("#F5F0E1")))
    }
}
