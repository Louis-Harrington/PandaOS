package com.pandaos.launcher

import android.graphics.Color

class Pal(val name: String, val bg: Int, val text: Int, val accent: Int) {
    val muted: Int get() = Ui.alpha(text, 160)
}

object Themes {
    private fun c(s: String): Int = Color.parseColor(s)

    val NAMES = arrayOf("Luxury", "Nature", "Midnight", "Earth", "Custom")
    val ACCENT_NAMES = arrayOf(
        "Theme default", "Brass", "Bronze", "Ice blue", "Copper", "Rose",
        "Sage", "Amber", "Violet", "Teal", "Coral", "Silver"
    )
    val ACCENTS = intArrayOf(
        0, c("#B5A642"), c("#CD7F32"), c("#9FD3F0"), c("#B87333"), c("#D98C9B"),
        c("#9CB48A"), c("#E0A526"), c("#9D8CD9"), c("#4FB3A9"), c("#E4745E"), c("#C0C6D0")
    )
    private val BASE = listOf(
        Pal("Luxury", c("#1C1C1E"), c("#F5F0E1"), c("#B5A642")),
        Pal("Nature", c("#1F3A2B"), c("#F3EBD8"), c("#CD7F32")),
        Pal("Midnight", c("#0B1630"), c("#C0C6D0"), c("#9FD3F0")),
        Pal("Earth", c("#2B1B14"), c("#E3D5BF"), c("#B87333"))
    )

    fun current(p: Profile = Store.p): Pal {
        val ov = ACCENTS[p.accent.coerceIn(0, ACCENTS.size - 1)]
        val base = if (p.theme in 0..3) {
            BASE[p.theme]
        } else {
            val a = if (ov == 0) c("#B5A642") else ov
            Pal("Custom", Ui.blend(Color.BLACK, a, 0.18f), c("#F4F1EA"), a)
        }
        return if (ov != 0) Pal(base.name, base.bg, base.text, ov) else base
    }
}
