package com.pandaos.launcher

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.View

/** Small, refined panda mark drawn with a few shapes (no image assets). */
class PandaLogoView(c: Context) : View(c) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var head = Color.parseColor("#F5F0E1")
    private var ears = Color.parseColor("#B5A642")
    private var patch = Color.parseColor("#1C1C1E")

    fun setColors(h: Int, e: Int, p: Int) {
        head = h; ears = e; patch = p
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val s = minOf(width, height).toFloat()
        val k = s / 56f
        canvas.save()
        canvas.translate(width / 2f, height / 2f)
        canvas.scale(k, k)
        canvas.translate(-54f, -56.5f)
        paint.color = ears
        canvas.drawCircle(37f, 40f, 9f, paint)
        canvas.drawCircle(71f, 40f, 9f, paint)
        paint.color = head
        canvas.drawCircle(54f, 58f, 24f, paint)
        paint.color = patch
        canvas.save(); canvas.rotate(20f, 44f, 57f)
        canvas.drawOval(RectF(38.5f, 49.5f, 49.5f, 64.5f), paint); canvas.restore()
        canvas.save(); canvas.rotate(-20f, 64f, 57f)
        canvas.drawOval(RectF(58.5f, 49.5f, 69.5f, 64.5f), paint); canvas.restore()
        canvas.drawCircle(54f, 66f, 2.8f, paint)
        canvas.restore()
    }
}
