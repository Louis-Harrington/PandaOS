package com.pandaos.launcher

import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import java.util.Calendar

/** Lightweight gradient wallpapers (no heavy rendering). */
object Wallpaper {
    val NAMES = arrayOf("Auto (time of day)", "Morning", "Afternoon", "Evening", "Night", "Abstract")

    fun period(): Int {
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return if (h in 5..11) 1 else if (h in 12..16) 2 else if (h in 17..20) 3 else 4
    }

    fun key(p: Profile): String = "${p.wallpaper}-${period()}-${p.theme}-${p.accent}-${p.perf}"

    fun drawable(p: Profile, pal: Pal): Drawable {
        if (p.perf) return ColorDrawable(pal.bg)
        val w = if (p.wallpaper == 0) period() else p.wallpaper
        if (w == 5) {
            val g = GradientDrawable()
            g.gradientType = GradientDrawable.RADIAL_GRADIENT
            g.gradientRadius = 1400f
            g.setGradientCenter(0.72f, 0.28f)
            g.colors = intArrayOf(Ui.blend(pal.bg, pal.accent, 0.35f), pal.bg, Ui.blend(pal.bg, Color.BLACK, 0.55f))
            return g
        }
        val tones = when (w) {
            1 -> Pair("#4F7F9C", "#D8A86A")
            2 -> Pair("#2F6E9E", "#7FB0C8")
            3 -> Pair("#3B2A4F", "#C8603C")
            else -> Pair("#07090F", "#14203A")
        }
        val top = Ui.blend(pal.bg, Color.parseColor(tones.first), 0.45f)
        val bottom = Ui.blend(pal.bg, Color.parseColor(tones.second), 0.40f)
        return GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(top, bottom))
    }
}
