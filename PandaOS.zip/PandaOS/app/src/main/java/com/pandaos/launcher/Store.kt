package com.pandaos.launcher

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

class Page(var name: String, val apps: MutableList<String> = ArrayList())

class Profile(var name: String) {
    val pages = ArrayList<Page>().apply { add(Page("Home")) }
    var pageIndex = 0
    var seeded = false
    var theme = 0
    var accent = 0
    var wallpaper = 0
    var typeface = 0
    var iconSize = 1
    var scale = 1
    var clockSize = 1
    var clockPos = 0
    var infoPos = 0
    var showClock = true
    var showDate = true
    var showInfo = true
    var showHints = true
    var animations = true
    var focusScale = 1
    var speed = 1
    var perf = false
    var sound = false
    var soundStyle = 0

    val page: Page get() = pages[pageIndex.coerceIn(0, pages.size - 1)]

    fun toJson(): JSONObject {
        val o = JSONObject()
        o.put("name", name); o.put("pageIndex", pageIndex); o.put("seeded", seeded)
        o.put("theme", theme); o.put("accent", accent); o.put("wallpaper", wallpaper)
        o.put("typeface", typeface); o.put("iconSize", iconSize); o.put("scale", scale)
        o.put("clockSize", clockSize); o.put("clockPos", clockPos); o.put("infoPos", infoPos)
        o.put("showClock", showClock); o.put("showDate", showDate); o.put("showInfo", showInfo)
        o.put("showHints", showHints); o.put("animations", animations)
        o.put("focusScale", focusScale); o.put("speed", speed); o.put("perf", perf)
        o.put("sound", sound); o.put("soundStyle", soundStyle)
        val pa = JSONArray()
        for (pg in pages) {
            val po = JSONObject()
            po.put("name", pg.name)
            val aa = JSONArray()
            for (a in pg.apps) aa.put(a)
            po.put("apps", aa)
            pa.put(po)
        }
        o.put("pages", pa)
        return o
    }

    companion object {
        fun fromJson(o: JSONObject): Profile {
            val p = Profile(o.optString("name", "Profile"))
            p.pages.clear()
            val pa = o.optJSONArray("pages")
            if (pa != null) {
                for (i in 0 until pa.length()) {
                    val po = pa.getJSONObject(i)
                    val pg = Page(po.optString("name", "Page"))
                    val aa = po.optJSONArray("apps")
                    if (aa != null) for (j in 0 until aa.length()) pg.apps.add(aa.getString(j))
                    p.pages.add(pg)
                }
            }
            if (p.pages.isEmpty()) p.pages.add(Page("Home"))
            p.pageIndex = o.optInt("pageIndex", 0).coerceIn(0, p.pages.size - 1)
            p.seeded = o.optBoolean("seeded", false)
            p.theme = o.optInt("theme", 0); p.accent = o.optInt("accent", 0)
            p.wallpaper = o.optInt("wallpaper", 0); p.typeface = o.optInt("typeface", 0)
            p.iconSize = o.optInt("iconSize", 1); p.scale = o.optInt("scale", 1)
            p.clockSize = o.optInt("clockSize", 1); p.clockPos = o.optInt("clockPos", 0)
            p.infoPos = o.optInt("infoPos", 0)
            p.showClock = o.optBoolean("showClock", true); p.showDate = o.optBoolean("showDate", true)
            p.showInfo = o.optBoolean("showInfo", true); p.showHints = o.optBoolean("showHints", true)
            p.animations = o.optBoolean("animations", true)
            p.focusScale = o.optInt("focusScale", 1); p.speed = o.optInt("speed", 1)
            p.perf = o.optBoolean("perf", false)
            p.sound = o.optBoolean("sound", false); p.soundStyle = o.optInt("soundStyle", 0)
            return p
        }
    }
}

object Store {
    private lateinit var sp: SharedPreferences
    private var inited = false
    val profiles = ArrayList<Profile>()
    var active = 0
    val hidden = LinkedHashSet<String>()
    val recents = ArrayList<String>()
    var startupAnim = true
    var idleMinutes = 5
    var autoStart = true

    val p: Profile get() = profiles[active.coerceIn(0, profiles.size - 1)]

    fun init(c: Context) {
        if (inited) return
        inited = true
        sp = c.applicationContext.getSharedPreferences("pandaos", Context.MODE_PRIVATE)
        load()
    }

    private fun load() {
        try {
            val s = sp.getString("data", null)
            if (s != null) {
                val o = JSONObject(s)
                active = o.optInt("active", 0)
                startupAnim = o.optBoolean("startup", true)
                idleMinutes = o.optInt("idle", 5)
                autoStart = o.optBoolean("autostart", true)
                val h = o.optJSONArray("hidden")
                if (h != null) for (i in 0 until h.length()) hidden.add(h.getString(i))
                val r = o.optJSONArray("recents")
                if (r != null) for (i in 0 until r.length()) recents.add(r.getString(i))
                val pr = o.optJSONArray("profiles")
                if (pr != null) for (i in 0 until pr.length()) profiles.add(Profile.fromJson(pr.getJSONObject(i)))
            }
        } catch (e: Exception) {
            profiles.clear(); hidden.clear(); recents.clear()
        }
        if (profiles.isEmpty()) profiles.add(Profile("Default"))
        if (active !in profiles.indices) active = 0
    }

    fun save() {
        try {
            val o = JSONObject()
            o.put("active", active); o.put("startup", startupAnim); o.put("idle", idleMinutes); o.put("autostart", autoStart)
            val h = JSONArray(); for (x in hidden) h.put(x); o.put("hidden", h)
            val r = JSONArray(); for (x in recents) r.put(x); o.put("recents", r)
            val pr = JSONArray(); for (x in profiles) pr.put(x.toJson()); o.put("profiles", pr)
            sp.edit().putString("data", o.toString()).apply()
        } catch (e: Exception) {
        }
    }

    fun reset() {
        profiles.clear(); profiles.add(Profile("Default"))
        active = 0; hidden.clear(); recents.clear(); startupAnim = true; idleMinutes = 5; autoStart = true
        save()
    }
}
