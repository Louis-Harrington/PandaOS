package com.pandaos.launcher

import android.content.Context
import android.content.Intent
import android.content.pm.ResolveInfo
import android.graphics.drawable.Drawable
import android.widget.Toast

class AppInfo(
    val pkg: String,
    val label: String,
    val activity: String,
    val tv: Boolean,
    val category: Int,
    val icon: Drawable
)

object AppRepo {
    @Volatile
    var apps: List<AppInfo> = emptyList()

    fun find(pkg: String): AppInfo? = apps.firstOrNull { it.pkg == pkg }

    fun scan(ctx: Context) {
        val pm = ctx.packageManager
        val map = LinkedHashMap<String, AppInfo>()
        try {
            val tvIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER)
            for (ri in pm.queryIntentActivities(tvIntent, 0)) add(ctx, ri, true, map)
            val allIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            for (ri in pm.queryIntentActivities(allIntent, 0)) {
                if (!map.containsKey(ri.activityInfo.packageName)) add(ctx, ri, false, map)
            }
        } catch (e: Exception) {
        }
        apps = map.values.sortedBy { it.label.lowercase() }
    }

    private fun add(ctx: Context, ri: ResolveInfo, tv: Boolean, map: MutableMap<String, AppInfo>) {
        val ai = ri.activityInfo ?: return
        if (ai.packageName == ctx.packageName || !ai.exported) return
        if (map.containsKey(ai.packageName)) return
        val pm = ctx.packageManager
        val label = ri.loadLabel(pm).toString()
        val icon = ri.loadIcon(pm)
        map[ai.packageName] = AppInfo(ai.packageName, label, ai.name, tv, ai.applicationInfo.category, icon)
    }

    fun launch(ctx: Context, a: AppInfo): Boolean {
        return try {
            val i = Intent(Intent.ACTION_MAIN)
                .addCategory(if (a.tv) Intent.CATEGORY_LEANBACK_LAUNCHER else Intent.CATEGORY_LAUNCHER)
                .setClassName(a.pkg, a.activity)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
            ctx.startActivity(i)
            Store.recents.remove(a.pkg)
            Store.recents.add(0, a.pkg)
            while (Store.recents.size > 20) Store.recents.removeAt(Store.recents.size - 1)
            Store.save()
            true
        } catch (e: Exception) {
            Toast.makeText(ctx, "Couldn't open ${a.label}", Toast.LENGTH_SHORT).show()
            false
        }
    }
}
