package com.pandaos.launcher

import android.content.pm.ApplicationInfo
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView

/** Application library: TV Apps / All Apps, search, categories, favourites, recents, hidden. */
class LibraryView(private val act: MainActivity, private var tvTab: Boolean, private var cat: Int) {
    companion object {
        val CATS = arrayOf("All", "Favourites", "Recent", "Entertainment", "Games", "Other", "Hidden")
    }

    private val pal = Themes.current()
    private val prof = Store.p
    private var query = ""
    private var items: List<AppInfo> = emptyList()
    val root = FrameLayout(act)
    private val grid = RecyclerView(act)
    private val empty = TextView(act)
    private val tabs = ArrayList<TextView>()
    private val chips = ArrayList<TextView>()
    private val adapter = Ad()

    private fun d(v: Int) = Ui.dp(act, v)

    private inner class VH(val cell: LinearLayout, val iv: ImageView, val label: TextView) :
        RecyclerView.ViewHolder(cell)

    private inner class Ad : RecyclerView.Adapter<VH>() {
        override fun getItemCount(): Int = items.size

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val cell = LinearLayout(act)
            cell.orientation = LinearLayout.VERTICAL
            cell.gravity = Gravity.CENTER_HORIZONTAL
            cell.setPadding(d(8), d(14), d(8), d(10))
            val iv = ImageView(act)
            cell.addView(iv, LinearLayout.LayoutParams(d(72), d(72)))
            val lb = Ui.text(act, "", 15f, pal.text)
            lb.maxLines = 1
            lb.ellipsize = TextUtils.TruncateAt.END
            lb.gravity = Gravity.CENTER
            cell.addView(lb, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { topMargin = d(8) })
            val lp = RecyclerView.LayoutParams(MATCH_PARENT, WRAP_CONTENT)
            lp.setMargins(d(6), d(6), d(6), d(6))
            cell.layoutParams = lp
            Ui.focusable(cell, pal, prof, 16)
            return VH(cell, iv, lb)
        }

        override fun onBindViewHolder(h: VH, position: Int) {
            val a = items[position]
            h.iv.setImageDrawable(a.icon)
            h.label.text = a.label
            h.cell.setOnClickListener { act.launchApp(a) }
            h.cell.setOnLongClickListener { act.appActions(a) { refresh() }; true }
        }
    }

    private fun chip(label: String, onClick: () -> Unit): TextView {
        val t = Ui.text(act, label, 16f, pal.text, "sans-serif-medium")
        t.setPadding(d(18), d(8), d(18), d(8))
        t.isFocusable = true
        t.isClickable = true
        t.setOnClickListener { onClick() }
        t.setOnFocusChangeListener { _, _ -> restyle() }
        return t
    }

    private fun restyle() {
        for (i in tabs.indices) paint(tabs[i], (i == 0) == tvTab)
        for (i in chips.indices) paint(chips[i], i == cat)
    }

    private fun paint(t: TextView, selected: Boolean) {
        t.setTextColor(if (selected) pal.accent else pal.text)
        t.background = when {
            t.isFocused -> Ui.round(Ui.alpha(pal.accent, 60), d(20).toFloat(), pal.accent, d(2))
            selected -> Ui.round(Ui.alpha(pal.accent, 28), d(20).toFloat())
            else -> null
        }
    }

    init {
        root.tag = this
        root.setBackgroundColor(Ui.alpha(pal.bg, 244))
        val col = LinearLayout(act)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(d(56), d(32), d(56), d(24))

        val header = LinearLayout(act)
        header.orientation = LinearLayout.HORIZONTAL
        header.gravity = Gravity.CENTER_VERTICAL
        header.addView(Ui.text(act, "Applications", 30f, pal.text, "sans-serif-light"),
            LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        val tvChip = chip("TV Apps") { tvTab = true; refresh() }
        val allChip = chip("All Apps") { tvTab = false; refresh() }
        tabs.add(tvChip); tabs.add(allChip)
        header.addView(tvChip); header.addView(allChip)
        col.addView(header)

        val search = EditText(act)
        search.hint = "Search apps"
        search.setSingleLine(true)
        search.setTextColor(pal.text)
        search.setHintTextColor(pal.muted)
        search.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
        search.background = Ui.round(Ui.alpha(pal.text, 22), d(14).toFloat())
        search.setPadding(d(18), d(10), d(18), d(10))
        search.imeOptions = EditorInfo.IME_ACTION_SEARCH
        search.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { query = s?.toString() ?: ""; refresh() }
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
        })
        col.addView(search, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = d(14) })

        val chipScroll = HorizontalScrollView(act)
        chipScroll.isHorizontalScrollBarEnabled = false
        val chipRow = LinearLayout(act)
        chipRow.orientation = LinearLayout.HORIZONTAL
        for (i in CATS.indices) {
            val c = chip(CATS[i]) { cat = i; refresh() }
            chips.add(c)
            chipRow.addView(c)
        }
        chipScroll.addView(chipRow)
        col.addView(chipScroll, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = d(10) })

        grid.layoutManager = GridLayoutManager(act, 6)
        grid.adapter = adapter
        grid.clipChildren = false
        grid.clipToPadding = false
        grid.setPadding(d(8), d(12), d(8), d(12))
        grid.itemAnimator = null
        empty.setTextColor(pal.muted)
        empty.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
        empty.gravity = Gravity.CENTER
        val content = FrameLayout(act)
        content.clipChildren = false
        content.addView(grid, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        content.addView(empty, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        col.addView(content, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f).apply { topMargin = d(8) })

        root.addView(col, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        refresh()
    }

    private fun compute(): List<AppInfo> {
        var l = AppRepo.apps.filter { if (tvTab) it.tv else true }
        val hidden = Store.hidden
        l = if (cat == 6) l.filter { it.pkg in hidden } else l.filter { it.pkg !in hidden }
        val ent = { a: AppInfo -> a.category == ApplicationInfo.CATEGORY_VIDEO || a.category == ApplicationInfo.CATEGORY_AUDIO }
        l = when (cat) {
            1 -> l.filter { it.pkg in Store.p.page.apps }
            2 -> Store.recents.mapNotNull { r -> l.firstOrNull { it.pkg == r } }
            3 -> l.filter { ent(it) }
            4 -> l.filter { it.category == ApplicationInfo.CATEGORY_GAME }
            5 -> l.filter { !ent(it) && it.category != ApplicationInfo.CATEGORY_GAME }
            else -> l
        }
        if (query.isNotBlank()) l = l.filter { it.label.contains(query, ignoreCase = true) }
        return l
    }

    fun refresh() {
        items = compute()
        adapter.notifyDataSetChanged()
        empty.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
        empty.text = when {
            AppRepo.apps.isEmpty() -> "Still scanning apps…"
            query.isNotBlank() -> "No apps match \"$query\""
            cat == 6 -> "No hidden apps"
            cat == 2 -> "Nothing opened yet"
            cat == 1 -> "No favourites on this page yet.\nHold OK on any app to add it."
            else -> "No apps in this section"
        }
        restyle()
    }
}
