package com.pandaos.launcher

import android.app.Activity
import android.app.ActivityManager
import android.app.AlertDialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.TransitionDrawable
import android.media.AudioManager
import android.net.ConnectivityManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.StatFs
import android.provider.Settings
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.SoundEffectConstants
import android.view.View
import android.view.ViewGroup
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextClock
import android.widget.TextView
import android.widget.Toast
import java.util.Collections
import java.util.Locale

class Row(
    val title: String,
    val sub: String = "",
    val stay: Boolean = false,
    val onClick: () -> Unit = {},
    val onLong: (() -> Unit)? = null
)

class MainActivity : Activity() {
    companion object {
        var splashShown = false
        private val ICON = intArrayOf(72, 96, 128)
        private val CLOCK = intArrayOf(60, 84, 108, 136)
        private val IDLE = intArrayOf(0, 1, 2, 5, 10, 15)
    }

    private class Ov(val view: View, val kind: String, val prevFocus: View?)
    private class Card(val title: String, val value: () -> String, val sub: String,
                       val click: (() -> Unit)?, val long: (() -> Unit)? = null)

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var root: FrameLayout
    private lateinit var backdrop: ImageView
    private lateinit var homeHolder: FrameLayout
    private lateinit var overlayLayer: FrameLayout
    private val stack = ArrayList<Ov>()
    private var favRow: LinearLayout? = null
    private var infoView: TextView? = null
    private var movingPkg: String? = null
    private var saver: View? = null
    private var splash: View? = null
    private var lastWallpaper: Drawable? = null
    private var wpKey = ""

    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) { scanApps() }
    }
    private val tick = object : Runnable {
        override fun run() {
            refreshWallpaper(true)
            updateInfo()
            handler.postDelayed(this, 60_000L)
        }
    }
    private val idle = Runnable { showSaver() }

    private fun dp(v: Int) = Ui.dp(this, v)
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    // ------------------------------------------------------------------ lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Store.init(this)
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
        root = FrameLayout(this)
        backdrop = ImageView(this)
        backdrop.scaleType = ImageView.ScaleType.FIT_XY
        homeHolder = FrameLayout(this)
        homeHolder.clipChildren = false
        overlayLayer = FrameLayout(this)
        root.addView(backdrop, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        root.addView(homeHolder, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        root.addView(overlayLayer, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        setContentView(root)
        rebuildHome()
        scanApps()
        val f = IntentFilter()
        f.addAction(Intent.ACTION_PACKAGE_ADDED)
        f.addAction(Intent.ACTION_PACKAGE_REMOVED)
        f.addAction(Intent.ACTION_PACKAGE_CHANGED)
        f.addDataScheme("package")
        registerReceiver(pkgReceiver, f)
        if (Store.startupAnim && !splashShown && !Store.p.perf) showSplash()
        splashShown = true
    }

    override fun onResume() {
        super.onResume()
        handler.post(tick)
        resetIdle()
        restoreFocus()
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(tick)
        handler.removeCallbacks(idle)
    }

    override fun onDestroy() {
        super.onDestroy()
        try { unregisterReceiver(pkgReceiver) } catch (e: Exception) { }
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        // HOME pressed while we are already the launcher: return to a clean home screen
        movingPkg = null
        hideSaver()
        closeAll()
    }

    @Suppress("OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        // A launcher never exits on BACK.
    }

    // ------------------------------------------------------------------ keys

    private fun resetIdle() {
        handler.removeCallbacks(idle)
        if (Store.idleMinutes > 0 && saver == null) handler.postDelayed(idle, Store.idleMinutes * 60_000L)
    }

    private fun edge(dir: Int): Boolean {
        val f = currentFocus ?: return true
        val row = favRow ?: return true
        if (f.parent !== row) return false
        return f.focusSearch(dir) == null
    }

    private fun playSound(k: Int) {
        val fx = if (Store.p.soundStyle == 1) SoundEffectConstants.CLICK else when (k) {
            KeyEvent.KEYCODE_DPAD_LEFT -> SoundEffectConstants.NAVIGATION_LEFT
            KeyEvent.KEYCODE_DPAD_RIGHT -> SoundEffectConstants.NAVIGATION_RIGHT
            KeyEvent.KEYCODE_DPAD_UP -> SoundEffectConstants.NAVIGATION_UP
            KeyEvent.KEYCODE_DPAD_DOWN -> SoundEffectConstants.NAVIGATION_DOWN
            else -> SoundEffectConstants.CLICK
        }
        root.playSoundEffect(fx)
    }

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        resetIdle()
        if (splash != null) return true
        if (saver != null) {
            if (e.action == KeyEvent.ACTION_DOWN) hideSaver()
            return true
        }
        val k = e.keyCode
        if (e.action == KeyEvent.ACTION_DOWN) {
            if (Store.p.sound && (k == KeyEvent.KEYCODE_DPAD_LEFT || k == KeyEvent.KEYCODE_DPAD_RIGHT ||
                        k == KeyEvent.KEYCODE_DPAD_UP || k == KeyEvent.KEYCODE_DPAD_DOWN)) playSound(k)
            if (stack.isNotEmpty()) {
                val kind = stack[stack.size - 1].kind
                if (k == KeyEvent.KEYCODE_BACK) { pop(); return true }
                if (kind == "menu" && k == KeyEvent.KEYCODE_DPAD_RIGHT) { pop(); return true }
                if (kind == "cc" && k == KeyEvent.KEYCODE_DPAD_DOWN) { pop(); return true }
            } else {
                val mp = movingPkg
                if (mp != null) {
                    when (k) {
                        KeyEvent.KEYCODE_DPAD_LEFT -> { moveFav(mp, -1); return true }
                        KeyEvent.KEYCODE_DPAD_RIGHT -> { moveFav(mp, 1); return true }
                        KeyEvent.KEYCODE_BACK -> { movingPkg = null; return true }
                    }
                }
                when (k) {
                    KeyEvent.KEYCODE_DPAD_LEFT -> if (edge(View.FOCUS_LEFT)) { openMenu(); return true }
                    KeyEvent.KEYCODE_DPAD_UP -> if (edge(View.FOCUS_UP)) { showControlCentre(0, false); return true }
                    KeyEvent.KEYCODE_MENU -> { openMenu(); return true }
                }
            }
        }
        return super.dispatchKeyEvent(e)
    }

    // ------------------------------------------------------------------ overlay stack

    private fun push(v: View, kind: String) {
        (stack.lastOrNull()?.view as? ViewGroup)?.descendantFocusability = ViewGroup.FOCUS_BLOCK_DESCENDANTS
        stack.add(Ov(v, kind, currentFocus))
        overlayLayer.addView(v, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        homeHolder.descendantFocusability = ViewGroup.FOCUS_BLOCK_DESCENDANTS
        v.post { v.requestFocus() }
    }

    private fun replaceTop(v: View, kind: String) {
        if (stack.isEmpty()) { push(v, kind); return }
        val old = stack.removeAt(stack.size - 1)
        overlayLayer.removeView(old.view)
        stack.add(Ov(v, kind, old.prevFocus))
        overlayLayer.addView(v, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        v.post { v.requestFocus() }
    }

    private fun pop() {
        if (stack.isEmpty()) return
        val o = stack.removeAt(stack.size - 1)
        overlayLayer.removeView(o.view)
        if (stack.isEmpty()) {
            homeHolder.descendantFocusability = ViewGroup.FOCUS_AFTER_DESCENDANTS
        } else {
            (stack[stack.size - 1].view as? ViewGroup)?.descendantFocusability = ViewGroup.FOCUS_AFTER_DESCENDANTS
        }
        val pf = o.prevFocus
        if (pf != null && pf.isAttachedToWindow) pf.requestFocus() else restoreFocus()
    }

    private fun closeAll() { while (stack.isNotEmpty()) pop() }

    private fun restoreFocus() {
        if (stack.isNotEmpty() || splash != null) return
        if (currentFocus != null) return
        favRow?.getChildAt(0)?.requestFocus()
    }

    // ------------------------------------------------------------------ home screen

    private fun refreshWallpaper(animate: Boolean) {
        val p = Store.p
        val key = Wallpaper.key(p)
        if (key == wpKey) return
        wpKey = key
        val d = Wallpaper.drawable(p, Themes.current())
        val old = lastWallpaper
        if (old != null && animate && p.animations && !p.perf) {
            val td = TransitionDrawable(arrayOf(old, d))
            backdrop.setImageDrawable(td)
            td.startTransition(700)
        } else {
            backdrop.setImageDrawable(d)
        }
        lastWallpaper = d
    }

    private fun rebuildHome() {
        val p = Store.p
        val pal = Themes.current()
        val k = Ui.SCALE[p.scale.coerceIn(0, 2)]
        refreshWallpaper(true)
        val h = homeHolder
        h.removeAllViews()
        favRow = null
        infoView = null

        // brand (top-left)
        val brand = LinearLayout(this)
        brand.orientation = LinearLayout.HORIZONTAL
        brand.gravity = Gravity.CENTER_VERTICAL
        val logo = PandaLogoView(this)
        logo.setColors(pal.text, pal.accent, pal.bg)
        brand.addView(logo, LinearLayout.LayoutParams(dp(32), dp(32)))
        val word = Ui.text(this, "PANDAOS", 13f, pal.muted, "sans-serif-medium")
        word.letterSpacing = 0.35f
        word.setPadding(dp(10), 0, 0, 0)
        brand.addView(word)
        h.addView(brand, FrameLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT, Gravity.TOP or Gravity.START)
            .apply { setMargins(dp(48), dp(34), 0, 0) })

        // clock + date
        if (p.showClock) {
            val col = LinearLayout(this)
            col.orientation = LinearLayout.VERTICAL
            col.gravity = when (p.clockPos) { 1 -> Gravity.START; 2 -> Gravity.END; else -> Gravity.CENTER_HORIZONTAL }
            val clock = TextClock(this)
            clock.format12Hour = "h:mm"
            clock.format24Hour = "HH:mm"
            clock.setTextColor(pal.text)
            clock.setTextSize(TypedValue.COMPLEX_UNIT_SP, CLOCK[p.clockSize.coerceIn(0, 3)] * k)
            clock.typeface = Typeface.create(Ui.FACES[p.typeface.coerceIn(0, 2)], Typeface.NORMAL)
            clock.includeFontPadding = false
            col.addView(clock)
            if (p.showDate) {
                val date = TextClock(this)
                date.format12Hour = "EEEE, d MMMM"
                date.format24Hour = "EEEE, d MMMM"
                date.setTextColor(pal.muted)
                date.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f * k)
                date.letterSpacing = 0.08f
                date.typeface = Typeface.create(Ui.FACES[p.typeface.coerceIn(0, 2)], Typeface.NORMAL)
                date.setPadding(0, dp(4), 0, 0)
                col.addView(date)
            }
            val g = when (p.clockPos) { 1 -> Gravity.TOP or Gravity.START; 2 -> Gravity.TOP or Gravity.END; else -> Gravity.TOP or Gravity.CENTER_HORIZONTAL }
            h.addView(col, FrameLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT, g)
                .apply { topMargin = if (p.clockPos == 1) dp(84) else dp(30); marginStart = dp(48); marginEnd = dp(48) })
        }

        // favourites row
        val scroll = HorizontalScrollView(this)
        scroll.isHorizontalScrollBarEnabled = false
        scroll.isFillViewport = true
        scroll.clipChildren = false
        scroll.clipToPadding = false
        scroll.overScrollMode = View.OVER_SCROLL_NEVER
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER
        row.clipChildren = false
        row.setPadding(dp(40), dp(20), dp(40), dp(20))
        scroll.addView(row, FrameLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT))
        h.addView(scroll, FrameLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT, Gravity.CENTER))
        favRow = row

        // system info corner
        if (p.showInfo) {
            val t = Ui.text(this, "", 13f, pal.muted)
            infoView = t
            h.addView(t, FrameLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT,
                (if (p.infoPos == 1) Gravity.END else Gravity.START) or Gravity.BOTTOM)
                .apply { setMargins(dp(48), 0, dp(48), dp(30)) })
        }
        if (p.showHints) {
            val t = Ui.text(this, "◀  Menu        ▲  Control Centre        OK  Open        hold OK  Options", 12f, Ui.alpha(pal.text, 110))
            t.letterSpacing = 0.05f
            h.addView(t, FrameLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
                .apply { bottomMargin = dp(30) })
        }
        rebuildFavs(null)
        updateInfo()
    }

    private fun seedIfNeeded() {
        val p = Store.p
        if (!p.seeded && AppRepo.apps.isNotEmpty()) {
            p.seeded = true
            AppRepo.apps.filter { it.tv }.take(6).forEach { p.pages[0].apps.add(it.pkg) }
            Store.save()
        }
    }

    private fun rebuildFavs(focusPkg: String? = null) {
        val row = favRow ?: return
        seedIfNeeded()
        val p = Store.p
        val pal = Themes.current()
        val keep = focusPkg ?: (currentFocus?.tag as? String)
        row.removeAllViews()
        for (pkg in p.page.apps) {
            val app = AppRepo.find(pkg) ?: continue
            row.addView(appTile(app, pal, p))
        }
        row.addView(addTile(pal, p))
        if (stack.isEmpty() && splash == null) {
            var target: View? = null
            for (i in 0 until row.childCount) if (row.getChildAt(i).tag == keep) target = row.getChildAt(i)
            (target ?: row.getChildAt(0))?.requestFocus()
        }
    }

    private fun appTile(app: AppInfo, pal: Pal, p: Profile): View {
        val k = Ui.SCALE[p.scale.coerceIn(0, 2)]
        val size = (ICON[p.iconSize.coerceIn(0, 2)] * k).toInt()
        val t = LinearLayout(this)
        t.orientation = LinearLayout.VERTICAL
        t.gravity = Gravity.CENTER_HORIZONTAL
        t.setPadding(dp(18), dp(18), dp(18), dp(14))
        t.tag = app.pkg
        val iv = ImageView(this)
        iv.setImageDrawable(app.icon)
        t.addView(iv, LinearLayout.LayoutParams(dp(size), dp(size)))
        val lb = Ui.text(this, app.label, 15f * k, pal.text)
        lb.maxLines = 1
        lb.ellipsize = TextUtils.TruncateAt.END
        lb.gravity = Gravity.CENTER
        lb.maxWidth = dp(size + 24)
        t.addView(lb, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { topMargin = dp(12) })
        t.layoutParams = LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { setMargins(dp(10), dp(10), dp(10), dp(10)) }
        Ui.focusable(t, pal, p, 22)
        t.setOnClickListener {
            if (movingPkg != null) { movingPkg = null; rebuildFavs(app.pkg) } else launchApp(app)
        }
        t.setOnLongClickListener { favActions(app); true }
        return t
    }

    private fun addTile(pal: Pal, p: Profile): View {
        val k = Ui.SCALE[p.scale.coerceIn(0, 2)]
        val size = (ICON[p.iconSize.coerceIn(0, 2)] * k).toInt()
        val t = LinearLayout(this)
        t.orientation = LinearLayout.VERTICAL
        t.gravity = Gravity.CENTER_HORIZONTAL
        t.setPadding(dp(18), dp(18), dp(18), dp(14))
        t.tag = "+add"
        val plus = Ui.text(this, "+", 40f, pal.accent, "sans-serif-light")
        plus.gravity = Gravity.CENTER
        plus.background = Ui.round(Ui.alpha(pal.text, 24), dp(size / 4).toFloat(), Ui.alpha(pal.text, 60), dp(1))
        t.addView(plus, LinearLayout.LayoutParams(dp(size), dp(size)))
        t.addView(Ui.text(this, "Add apps", 15f * k, pal.muted),
            LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { topMargin = dp(12) })
        t.layoutParams = LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { setMargins(dp(10), dp(10), dp(10), dp(10)) }
        Ui.focusable(t, pal, p, 22)
        t.setOnClickListener { openLibrary(true, 0) }
        return t
    }

    private fun moveFav(pkg: String, d: Int) {
        val list = Store.p.page.apps
        val i = list.indexOf(pkg)
        val j = i + d
        if (i >= 0 && j in list.indices) {
            Collections.swap(list, i, j)
            Store.save()
            rebuildFavs(pkg)
        }
    }

    private fun fmt(b: Long): String =
        if (b >= (1L shl 30)) String.format(Locale.US, "%.1f GB", b / 1073741824.0)
        else String.format(Locale.US, "%d MB", b / 1048576L)

    private fun storage(): Pair<Long, Long> {
        val s = StatFs(Environment.getDataDirectory().path)
        return Pair(s.availableBytes, s.totalBytes)
    }

    private fun memory(): Pair<Long, Long> {
        val mi = ActivityManager.MemoryInfo()
        (getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        return Pair(mi.availMem, mi.totalMem)
    }

    private fun updateInfo() {
        val t = infoView ?: return
        try {
            val s = storage()
            val m = memory()
            t.text = "Storage ${fmt(s.first)} free of ${fmt(s.second)}     ·     Memory ${fmt(m.first)} free of ${fmt(m.second)}"
        } catch (e: Exception) {
            t.text = ""
        }
    }

    private fun scanApps() {
        Thread {
            AppRepo.scan(this)
            runOnUiThread {
                rebuildFavs(null)
                (stack.firstOrNull { it.kind == "lib" }?.view?.tag as? LibraryView)?.refresh()
            }
        }.start()
    }

    // ------------------------------------------------------------------ actions

    fun launchApp(app: AppInfo) { AppRepo.launch(this, app) }

    fun appActions(app: AppInfo, done: () -> Unit) {
        val p = Store.p
        showPanel(app.label) {
            val isFav = p.page.apps.contains(app.pkg)
            val isHidden = Store.hidden.contains(app.pkg)
            listOf(
                Row(title = "Open", onClick = { pop(); launchApp(app) }),
                Row(title = if (isFav) "Remove from favourites" else "Add to favourites",
                    sub = "Page: ${p.page.name}",
                    onClick = {
                        if (isFav) p.page.apps.remove(app.pkg) else p.page.apps.add(app.pkg)
                        Store.save(); pop(); rebuildFavs(); done()
                    }),
                Row(title = if (isHidden) "Show in library" else "Hide from library",
                    onClick = {
                        if (isHidden) Store.hidden.remove(app.pkg) else Store.hidden.add(app.pkg)
                        Store.save(); pop(); done()
                    }),
                Row(title = "Cancel", onClick = { pop() })
            )
        }
    }

    private fun favActions(app: AppInfo) {
        showPanel(app.label) {
            listOf(
                Row(title = "Move", sub = "Then use ◀ ▶ and press OK when done",
                    onClick = { pop(); movingPkg = app.pkg; toast("Use ◀ ▶ to move · OK to finish") }),
                Row(title = "Remove from this page",
                    onClick = { Store.p.page.apps.remove(app.pkg); Store.save(); pop(); rebuildFavs() }),
                Row(title = "Cancel", onClick = { pop() })
            )
        }
    }

    private fun startSafe(action: String, uri: Uri? = null) {
        try {
            val i = Intent(action)
            if (uri != null) i.data = uri
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        } catch (e: Exception) {
            toast("Not available on this TV's firmware")
        }
    }

    private fun ask(title: String, initial: String, ok: (String) -> Unit) {
        val et = EditText(this)
        et.setText(initial)
        et.setSingleLine(true)
        et.setSelection(et.text.length)
        AlertDialog.Builder(this).setTitle(title).setView(et)
            .setPositiveButton("Save") { _, _ ->
                val s = et.text.toString().trim()
                if (s.isNotEmpty()) ok(s)
            }
            .setNegativeButton("Cancel", null).show()
    }

    private fun confirm(title: String, msg: String, ok: () -> Unit) {
        AlertDialog.Builder(this).setTitle(title).setMessage(msg)
            .setPositiveButton("Yes") { _, _ -> ok() }
            .setNegativeButton("Cancel", null).show()
    }

    // ------------------------------------------------------------------ generic list panel

    private fun rowView(r: Row, pal: Pal, p: Profile): View {
        val v = LinearLayout(this)
        v.orientation = LinearLayout.VERTICAL
        v.setPadding(dp(22), dp(12), dp(22), dp(12))
        v.addView(Ui.text(this, r.title, 20f, pal.text))
        if (r.sub.isNotEmpty()) v.addView(Ui.text(this, r.sub, 14f, pal.muted))
        v.layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(4) }
        Ui.focusable(v, pal, p, 14, 1.03f)
        return v
    }

    private fun showPanel(title: String, rows: () -> List<Row>): () -> Unit {
        val pal = Themes.current()
        val p = Store.p
        val scrim = FrameLayout(this)
        scrim.setBackgroundColor(Color.argb(150, 0, 0, 0))
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(dp(32), dp(28), dp(32), dp(24))
        card.background = Ui.round(Ui.alpha(pal.bg, 245), dp(28).toFloat(), Ui.alpha(pal.text, 40), dp(1))
        card.addView(Ui.text(this, title, 26f, pal.text, "sans-serif-light"))
        val list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        val sv = ScrollView(this)
        sv.isVerticalScrollBarEnabled = false
        sv.addView(list)
        card.addView(sv, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(16) })
        scrim.addView(card, FrameLayout.LayoutParams(dp(640), WRAP_CONTENT, Gravity.CENTER))

        fun render(focus: Int) {
            list.removeAllViews()
            val rs = rows()
            rs.forEachIndexed { i, r ->
                val v = rowView(r, pal, p)
                v.setOnClickListener { r.onClick(); if (r.stay) render(i) }
                val ol = r.onLong
                if (ol != null) v.setOnLongClickListener { ol(); true }
                list.addView(v)
            }
            if (focus >= 0 && list.childCount > 0) list.getChildAt(minOf(focus, list.childCount - 1)).requestFocus()
        }
        render(-1)
        push(scrim, "panel")
        return { render(0) }
    }

    // ------------------------------------------------------------------ navigation menu

    private fun openMenu() {
        val pal = Themes.current()
        val scrim = FrameLayout(this)
        scrim.setBackgroundColor(Color.argb(90, 0, 0, 0))
        val panel = LinearLayout(this)
        panel.orientation = LinearLayout.VERTICAL
        panel.setPadding(dp(28), dp(32), dp(28), dp(32))
        panel.background = Ui.round(Ui.alpha(pal.bg, 242), dp(30).toFloat(), Ui.alpha(pal.text, 40), dp(1))
        val brand = LinearLayout(this)
        brand.orientation = LinearLayout.HORIZONTAL
        brand.gravity = Gravity.CENTER_VERTICAL
        val logo = PandaLogoView(this)
        logo.setColors(pal.text, pal.accent, pal.bg)
        brand.addView(logo, LinearLayout.LayoutParams(dp(34), dp(34)))
        val w = Ui.text(this, "PANDAOS", 15f, pal.text, "sans-serif-medium")
        w.letterSpacing = 0.35f
        w.setPadding(dp(12), 0, 0, 0)
        brand.addView(w)
        panel.addView(brand)
        panel.addView(Ui.text(this, "Profile · ${Store.p.name}", 13f, pal.muted),
            LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { topMargin = dp(6); bottomMargin = dp(18) })
        val items = listOf<Pair<String, () -> Unit>>(
            Pair<String, () -> Unit>("Home", { closeAll() }),
            Pair<String, () -> Unit>("Applications", { openLibrary(true, 0) }),
            Pair<String, () -> Unit>("Entertainment", { openLibrary(true, 3) }),
            Pair<String, () -> Unit>("Custom Pages", { showPages() }),
            Pair<String, () -> Unit>("Settings", { showSettings(0, -1, false) }),
            Pair<String, () -> Unit>("Profile Switcher", { showProfiles() })
        )
        for (entry in items) {
            val t = Ui.text(this, entry.first, 22f, pal.text, "sans-serif-light")
            t.setPadding(dp(22), dp(14), dp(22), dp(14))
            t.layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(4) }
            Ui.focusable(t, pal, Store.p, 16, 1.04f)
            val action = entry.second
            t.setOnClickListener { action() }
            panel.addView(t)
        }
        scrim.addView(panel, FrameLayout.LayoutParams(dp(340), WRAP_CONTENT, Gravity.START or Gravity.CENTER_VERTICAL)
            .apply { marginStart = dp(28) })
        if (Store.p.animations && !Store.p.perf) {
            panel.translationX = -dp(380).toFloat()
            panel.animate().translationX(0f).setDuration(Ui.SPEED[Store.p.speed.coerceIn(0, 2)]).start()
        }
        push(scrim, "menu")
    }

    private fun openLibrary(tv: Boolean, cat: Int) {
        push(LibraryView(this, tv, cat).root, "lib")
    }

    // ------------------------------------------------------------------ pages & profiles

    private fun showPages() {
        var render: (() -> Unit)? = null
        render = showPanel("Custom pages") {
            val p = Store.p
            val rows = ArrayList<Row>()
            p.pages.forEachIndexed { i, pg ->
                rows.add(Row(
                    title = (if (i == p.pageIndex) "●  " else "○  ") + pg.name,
                    sub = "${pg.apps.size} apps  ·  hold OK for options",
                    onClick = { p.pageIndex = i; Store.save(); closeAll(); rebuildFavs() },
                    onLong = { pageOptions(i) { render?.invoke() } }
                ))
            }
            rows.add(Row(title = "+  New page", onClick = {
                p.pages.add(Page("Page ${p.pages.size + 1}"))
                p.pageIndex = p.pages.size - 1
                Store.save(); closeAll(); rebuildFavs()
            }))
            rows
        }
    }

    private fun pageOptions(i: Int, changed: () -> Unit) {
        val p = Store.p
        val pg = p.pages[i]
        showPanel("Page: ${pg.name}") {
            val rows = ArrayList<Row>()
            rows.add(Row(title = "Rename", onClick = {
                pop(); ask("Rename page", pg.name) { pg.name = it; Store.save(); changed() }
            }))
            if (i > 0) rows.add(Row(title = "Move earlier", onClick = {
                val cur = p.page; Collections.swap(p.pages, i, i - 1); p.pageIndex = p.pages.indexOf(cur)
                Store.save(); pop(); changed()
            }))
            if (i < p.pages.size - 1) rows.add(Row(title = "Move later", onClick = {
                val cur = p.page; Collections.swap(p.pages, i, i + 1); p.pageIndex = p.pages.indexOf(cur)
                Store.save(); pop(); changed()
            }))
            if (p.pages.size > 1) rows.add(Row(title = "Delete page", onClick = {
                val cur = p.page
                p.pages.removeAt(i)
                p.pageIndex = maxOf(0, p.pages.indexOf(cur))
                Store.save(); pop(); changed(); rebuildFavs()
            }))
            rows.add(Row(title = "Cancel", onClick = { pop() }))
            rows
        }
    }

    private fun switchProfile(i: Int) {
        Store.active = i
        Store.save()
        wpKey = ""
        closeAll()
        rebuildHome()
    }

    private fun showProfiles() {
        var render: (() -> Unit)? = null
        render = showPanel("Profile switcher") {
            val rows = ArrayList<Row>()
            Store.profiles.forEachIndexed { i, pr ->
                rows.add(Row(
                    title = (if (i == Store.active) "●  " else "○  ") + pr.name,
                    sub = "${pr.pages.size} page(s)  ·  hold OK for options",
                    onClick = { switchProfile(i) },
                    onLong = { profileOptions(i) { render?.invoke() } }
                ))
            }
            rows.add(Row(title = "+  New profile", onClick = {
                Store.profiles.add(Profile("Profile ${Store.profiles.size + 1}"))
                switchProfile(Store.profiles.size - 1)
            }))
            rows
        }
    }

    private fun profileOptions(i: Int, changed: () -> Unit) {
        val pr = Store.profiles[i]
        showPanel("Profile: ${pr.name}") {
            val rows = ArrayList<Row>()
            rows.add(Row(title = "Rename", onClick = {
                pop(); ask("Rename profile", pr.name) { pr.name = it; Store.save(); changed() }
            }))
            if (Store.profiles.size > 1) rows.add(Row(title = "Delete profile", onClick = {
                val cur = Store.p
                Store.profiles.removeAt(i)
                Store.active = maxOf(0, Store.profiles.indexOf(cur))
                Store.save(); wpKey = ""; pop(); changed(); rebuildHome()
            }))
            rows.add(Row(title = "Cancel", onClick = { pop() }))
            rows
        }
    }

    // ------------------------------------------------------------------ control centre

    private fun networkText(): String {
        return try {
            val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val ni = cm.activeNetworkInfo
            if (ni == null || !ni.isConnected) "Offline" else when (ni.type) {
                ConnectivityManager.TYPE_WIFI -> "Wi-Fi connected"
                ConnectivityManager.TYPE_ETHERNET -> "Ethernet connected"
                else -> "Connected"
            }
        } catch (e: Exception) {
            "Unavailable"
        }
    }

    private fun showControlCentre(focus: Int, replace: Boolean) {
        val pal = Themes.current()
        val p = Store.p
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val cards = listOf(
            Card("NETWORK", { networkText() }, "OK · network settings", { startSafe(Settings.ACTION_WIFI_SETTINGS) }),
            Card("VOLUME", { "${am.getStreamVolume(AudioManager.STREAM_MUSIC)} / ${am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)}" },
                "OK  +   ·   hold OK  −\n(your TV may fix volume)",
                { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI) },
                { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI) }),
            Card("STORAGE", { try { fmt(storage().first) + " free" } catch (e: Exception) { "Unavailable" } },
                try { "of ${fmt(storage().second)} internal" } catch (e: Exception) { "" }, null),
            Card("MEMORY", { try { fmt(memory().first) + " free" } catch (e: Exception) { "Unavailable" } },
                try { "of ${fmt(memory().second)} total" } catch (e: Exception) { "" }, null),
            Card("WALLPAPER", { Wallpaper.NAMES[p.wallpaper.coerceIn(0, 5)] }, "OK · next wallpaper", {
                p.wallpaper = (p.wallpaper + 1) % Wallpaper.NAMES.size
                Store.save(); rebuildHome(); showControlCentre(4, true)
            }),
            Card("THEME", { Themes.NAMES[p.theme.coerceIn(0, 4)] }, "OK · next theme", {
                p.theme = (p.theme + 1) % Themes.NAMES.size
                Store.save(); rebuildHome(); showControlCentre(5, true)
            }),
            Card("DISPLAY", { "System settings" }, "Brightness & resolution are\ncontrolled by Android / your TV",
                { startSafe(Settings.ACTION_DISPLAY_SETTINGS) }),
            Card("PANDAOS", { "Settings" }, "OK · Customisation Studio", { showSettings(0, -1, false) })
        )
        val scrim = FrameLayout(this)
        scrim.setBackgroundColor(Color.argb(90, 0, 0, 0))
        val panel = LinearLayout(this)
        panel.orientation = LinearLayout.VERTICAL
        panel.setPadding(dp(28), dp(22), dp(28), dp(24))
        panel.background = Ui.round(Ui.alpha(pal.bg, 242), dp(30).toFloat(), Ui.alpha(pal.text, 40), dp(1))
        panel.addView(Ui.text(this, "Control Centre", 22f, pal.text, "sans-serif-light"))
        val hs = HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        hs.clipChildren = false
        hs.clipToPadding = false
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.clipChildren = false
        row.setPadding(dp(4), dp(14), dp(4), dp(8))
        hs.addView(row)
        panel.addView(hs)
        val values = ArrayList<Pair<TextView, () -> String>>()
        val refreshValues = { for (x in values) x.first.text = x.second() }
        for (c in cards) {
            val v = LinearLayout(this)
            v.orientation = LinearLayout.VERTICAL
            v.setPadding(dp(20), dp(16), dp(20), dp(16))
            v.addView(Ui.text(this, c.title, 12f, pal.accent, "sans-serif-medium").apply { letterSpacing = 0.2f })
            val val1 = Ui.text(this, c.value(), 22f, pal.text, "sans-serif-light")
            values.add(Pair(val1, c.value))
            v.addView(val1, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { topMargin = dp(6) })
            v.addView(Ui.text(this, c.sub, 12f, pal.muted), LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { topMargin = dp(6) })
            v.layoutParams = LinearLayout.LayoutParams(dp(230), WRAP_CONTENT).apply { setMargins(dp(6), 0, dp(6), 0) }
            Ui.focusable(v, pal, p, 18, 1.05f)
            val click = c.click
            val long = c.long
            if (click != null) v.setOnClickListener { click(); handler.post { refreshValues() } }
            if (long != null) v.setOnLongClickListener { long(); handler.post { refreshValues() }; true }
            row.addView(v)
        }
        scrim.addView(panel, FrameLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT, Gravity.TOP)
            .apply { setMargins(dp(40), dp(24), dp(40), 0) })
        if (!replace && p.animations && !p.perf) {
            panel.translationY = -dp(300).toFloat()
            panel.animate().translationY(0f).setDuration(Ui.SPEED[p.speed.coerceIn(0, 2)]).start()
        }
        if (replace) replaceTop(scrim, "cc") else push(scrim, "cc")
        panel.post { row.getChildAt(focus.coerceIn(0, row.childCount - 1))?.requestFocus() }
    }

    // ------------------------------------------------------------------ Customisation Studio

    private fun cyc(title: String, names: Array<String>, get: () -> Int, set: (Int) -> Unit) =
        Row(title = title, sub = names[get().coerceIn(0, names.size - 1)], stay = true,
            onClick = { set((get() + 1) % names.size) })

    private fun tog(title: String, get: () -> Boolean, set: (Boolean) -> Unit) =
        Row(title = title, sub = if (get()) "On" else "Off", stay = true, onClick = { set(!get()) })

    private fun settingsRows(tab: Int): List<Row> {
        val p = Store.p
        return when (tab) {
            0 -> listOf(
                cyc("Wallpaper", Wallpaper.NAMES, { p.wallpaper }, { p.wallpaper = it }),
                cyc("Accent colour", Themes.ACCENT_NAMES, { p.accent }, { p.accent = it }),
                cyc("Typography", Ui.FACE_NAMES, { p.typeface }, { p.typeface = it }),
                cyc("Icon size", arrayOf("Small", "Medium", "Large"), { p.iconSize }, { p.iconSize = it }),
                cyc("Interface scale", arrayOf("90%", "100%", "115%"), { p.scale }, { p.scale = it })
            )
            1 -> Themes.NAMES.mapIndexed { i, n ->
                Row(title = n,
                    sub = if (p.theme == i) "Active" else if (i == 4) "Built from your accent colour (Appearance tab)" else "Press OK to apply",
                    stay = true, onClick = { p.theme = i })
            }
            2 -> listOf(
                tog("Show clock", { p.showClock }, { p.showClock = it }),
                cyc("Clock position", arrayOf("Top centre", "Top left", "Top right"), { p.clockPos }, { p.clockPos = it }),
                cyc("Clock size", arrayOf("Small", "Medium", "Large", "Extra large"), { p.clockSize }, { p.clockSize = it }),
                tog("Show date", { p.showDate }, { p.showDate = it }),
                tog("Show system information", { p.showInfo }, { p.showInfo = it }),
                cyc("Information corner", arrayOf("Bottom left", "Bottom right"), { p.infoPos }, { p.infoPos = it }),
                tog("Show button hints", { p.showHints }, { p.showHints = it }),
                Row(title = "Arrange favourites", sub = "On Home: hold OK on a favourite → Move"),
                Row(title = "Manage home pages", sub = "Create, rename, reorder, delete", onClick = { showPages() })
            )
            3 -> listOf(
                tog("Animations", { p.animations }, { p.animations = it }),
                cyc("Transition speed", arrayOf("Fast", "Normal", "Slow"), { p.speed }, { p.speed = it }),
                cyc("Focus scaling", arrayOf("Subtle", "Normal", "Strong"), { p.focusScale }, { p.focusScale = it }),
                tog("Performance mode", { p.perf }, { p.perf = it })
            )
            4 -> listOf(
                tog("Navigation sounds", { p.sound }, { p.sound = it }),
                cyc("Sound style", arrayOf("Navigation tones", "Click"), { p.soundStyle }, { p.soundStyle = it }),
                Row(title = "Volume", sub = "Sounds follow your TV's system volume (Control Centre shows it)")
            )
            else -> {
                val s = try { "${fmt(storage().first)} free of ${fmt(storage().second)}" } catch (e: Exception) { "Unavailable" }
                listOf(
                    Row(title = "About PandaOS", sub = "Version 1.0 · Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT}) · ${Build.MODEL}"),
                    Row(title = "Storage", sub = s),
                    Row(title = "Permissions", sub = "PandaOS asks for no risky permissions. OK opens app details.",
                        onClick = { startSafe(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")) }),
                    Row(title = "Set as default launcher", sub = "Opens Android Home settings if your TV supports it",
                        onClick = { startSafe(Settings.ACTION_HOME_SETTINGS) }),
                    tog("Launch PandaOS when the TV starts", { Store.autoStart }, { Store.autoStart = it }),
                    tog("Startup animation", { Store.startupAnim }, { Store.startupAnim = it }),
                    cyc("Screensaver timer", arrayOf("Off", "1 min", "2 min", "5 min", "10 min", "15 min"),
                        { IDLE.indexOf(Store.idleMinutes).coerceAtLeast(0) },
                        { Store.idleMinutes = IDLE[it]; resetIdle() }),
                    Row(title = "System screensaver", sub = "Pick \"PandaOS Clock\" in Android screen saver settings",
                        onClick = { startSafe(Settings.ACTION_DREAM_SETTINGS) }),
                    Row(title = "Reset launcher preferences", sub = "Erases profiles, pages, favourites and settings",
                        onClick = {
                            confirm("Reset PandaOS?", "This erases all PandaOS profiles, pages and settings.") {
                                Store.reset(); wpKey = ""; closeAll(); rebuildHome()
                            }
                        })
                )
            }
        }
    }

    private fun showSettings(startTab: Int, startRow: Int, replace: Boolean) {
        val pal = Themes.current()
        val p = Store.p
        val scrim = FrameLayout(this)
        scrim.setBackgroundColor(Color.argb(70, 0, 0, 0))
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(dp(28), dp(24), dp(28), dp(20))
        card.background = Ui.round(Ui.alpha(pal.bg, 244), dp(28).toFloat(), Ui.alpha(pal.text, 40), dp(1))
        card.addView(Ui.text(this, "Customisation Studio", 24f, pal.text, "sans-serif-light"))
        val names = arrayOf("Appearance", "Themes", "Layout", "Animations", "Sound", "System")
        val tabRow = LinearLayout(this)
        tabRow.orientation = LinearLayout.HORIZONTAL
        val tabViews = ArrayList<TextView>()
        val list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        var cur = startTab

        fun styleTabs() {
            tabViews.forEachIndexed { i, t -> t.setTextColor(if (i == cur) pal.accent else pal.text) }
        }

        fun fill() {
            list.removeAllViews()
            val rows = settingsRows(cur)
            rows.forEachIndexed { i, r ->
                val v = rowView(r, pal, p)
                v.setOnClickListener {
                    r.onClick()
                    if (r.stay) { Store.save(); rebuildHome(); showSettings(cur, i, true) }
                }
                list.addView(v)
            }
        }

        names.forEachIndexed { i, n ->
            val t = Ui.text(this, n, 17f, pal.text, "sans-serif-medium")
            t.setPadding(dp(16), dp(10), dp(16), dp(10))
            Ui.focusable(t, pal, p, 14, 1.04f) { has -> if (has && cur != i) { cur = i; styleTabs(); fill() } }
            tabViews.add(t)
            tabRow.addView(t)
        }
        card.addView(tabRow, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { topMargin = dp(12) })
        val sv = ScrollView(this)
        sv.isVerticalScrollBarEnabled = false
        sv.addView(list)
        card.addView(sv, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f).apply { topMargin = dp(12) })
        styleTabs()
        fill()
        scrim.addView(card, FrameLayout.LayoutParams(dp(780), dp(560), Gravity.CENTER))
        if (replace) replaceTop(scrim, "settings") else push(scrim, "settings")
        card.post {
            if (startRow >= 0 && startRow < list.childCount) list.getChildAt(startRow).requestFocus()
            else tabViews[startTab.coerceIn(0, tabViews.size - 1)].requestFocus()
        }
    }

    // ------------------------------------------------------------------ screensaver & splash

    private fun showSaver() {
        if (saver != null || splash != null) return
        val s = ClockScreen.build(this, Themes.current().text)
        saver = s
        root.addView(s, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
    }

    private fun hideSaver() {
        val s = saver ?: return
        root.removeView(s)
        saver = null
        resetIdle()
    }

    private fun showSplash() {
        val pal = Themes.current()
        val f = FrameLayout(this)
        f.setBackgroundColor(Color.parseColor("#0E0E10"))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER_HORIZONTAL
        col.alpha = 0f
        val logo = PandaLogoView(this)
        logo.setColors(pal.text, pal.accent, Color.parseColor("#0E0E10"))
        col.addView(logo, LinearLayout.LayoutParams(dp(84), dp(84)))
        val w = Ui.text(this, "PANDAOS", 22f, pal.text, "sans-serif-light")
        w.letterSpacing = 0.5f
        col.addView(w, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { topMargin = dp(18) })
        f.addView(col, FrameLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT, Gravity.CENTER))
        val credit = Ui.text(this, "Created By Anagh Sharma", 10f, pal.text, "sans-serif-light")
        credit.letterSpacing = 0.22f
        credit.alpha = 0f
        f.addView(credit, FrameLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
            .apply { bottomMargin = dp(26) })
        credit.animate().alpha(0.45f).setStartDelay(900).setDuration(900).start()
        root.addView(f, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        splash = f
        col.animate().alpha(1f).setDuration(700).withEndAction {
            handler.postDelayed({
                f.animate().alpha(0f).setDuration(500).withEndAction {
                    root.removeView(f)
                    splash = null
                    restoreFocus()
                }.start()
            }, 1400)
        }.start()
    }
}
