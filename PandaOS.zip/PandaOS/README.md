# PandaOS — Android TV launcher (Stages 1–3 + parts of 4)

Native Kotlin launcher for Android TV 9 (API 28+), built for a Xiaomi / Mi TV. No webview, no paid services, no root.

## Build the APK from your phone (free, no computer)

1. Make a free account on github.com. Create a **new repository** (Public or Private).
2. In the repo tap **Add file → Upload files** and upload **PandaOS.zip** (the zip itself, do not unzip).
3. Tap **Add file → Create new file**. Name it exactly `.github/workflows/build.yml` and paste the contents of the `build.yml` file that came with this project. Tap **Commit changes**.
4. Open the **Actions** tab. A run called "Build PandaOS APK" starts automatically (about 5–8 minutes). Green tick = done.
5. Get the APK from **Releases** (right side of the repo page) → newest build → `PandaOS.apk`.

If the run shows a red cross, open it, copy the error text from the failed step and send it to me.

## Install on the Mi TV

Option A (easiest): install **Send Files to TV** on the phone and the TV (both free on Play Store), send `PandaOS.apk`, open it on the TV and install. Allow "install unknown apps" when asked.

Option B: install **Downloader** on the TV, allow it to install unknown apps, and type the release link: `github.com/YOUR_USERNAME/YOUR_REPO/releases/latest/download/PandaOS.apk` (repository must be Public for this).

## Default launcher, HOME button and automatic startup

How it is built (all standard Android, no root, no hacks):
- PandaOS declares the **HOME**, **LEANBACK_LAUNCHER** and **LAUNCHER** intent filters, so it appears as a selectable home app.
- It is `singleTask`, so pressing the remote's **HOME** button brings PandaOS back to a clean home screen (closes menus, ends the screensaver).
- A boot receiver (`RECEIVE_BOOT_COMPLETED`) opens PandaOS after the TV finishes starting. You can switch this off in Settings → System → "Launch PandaOS when the TV starts".

How to select it:
1. Open PandaOS from the TV's app list → Settings → System → "Set as default launcher". This opens Android's Home settings if your TV has them.
2. Or on the TV: Settings → Device Preferences → Home screen (or Default apps). Names vary by firmware.
3. Some TVs show a "Select a home app" popup the first time you press HOME. Choose PandaOS and "Always".

Xiaomi / Mi TV limitations (please read):
- Mi TV firmware often uses Xiaomi's own launcher (PatchWall) and may hide or lock the home-app chooser. If there is no chooser, PandaOS stays a normal app; no way around it is attempted here.
- Automatic start after boot is **not guaranteed**. Android only delivers the boot broadcast if the app has been opened at least once, and Xiaomi may add auto-start or battery restrictions. If the TV does not open PandaOS by itself, check Settings → Apps → PandaOS for any "Autostart" / "Background" permission, and open PandaOS once after installing.
- If PandaOS is the default launcher, Android starts it itself at boot, which is the most reliable route.
- A TV that wakes from standby (not a full restart) usually returns to the last screen; pressing HOME brings PandaOS back.

## Remote controls

LEFT at the left edge → navigation menu. UP at the top edge → Control Centre. Hold OK on a favourite → Move / Remove. BACK closes overlays. MENU button also opens the navigation menu.

## What works

Home (clock, date, favourite apps, storage and memory info, time-of-day wallpaper) · app discovery (TV Apps + All Apps) · search, categories, favourites, recent apps, hide apps · custom pages · local profiles · Control Centre · Customisation Studio (appearance, 4 themes + custom accent, layout, animations, sound, system) · startup animation (with a small "Created By Anagh Sharma" credit) · in-launcher clock screensaver · real DreamService screensaver · performance mode · fully offline.

## Not done yet / limitations (honest list)

- **Weather widget**: not implemented yet (needs location + an online provider). Nothing fake is shown.
- **Wallpapers** are lightweight gradients (nature-inspired time-of-day and abstract). Picking your own photos is not implemented yet.
- **Custom colour picker** is a set of 11 accent swatches + a "Custom" theme built from the accent, not a free RGB picker.
- **Control Centre**: volume may be fixed by the TV (HDMI/CEC); brightness, restart etc. are not faked, display card opens Android settings.
- **Screensaver**: the in-launcher timer only runs while PandaOS is on screen. For a system-wide one, choose "PandaOS Clock" in Android's screen saver settings (Settings → Device Preferences → Screen saver; Xiaomi may hide this).
- The TV banner is a symbol only (no text).
- This source was written without an Android SDK available, so it has **not been compiled or run on a real TV yet**. The first GitHub build may show a small compile error that needs fixing.

## Troubleshooting

- *Build fails*: send me the red error lines from the Actions log.
- *Can't install APK*: enable "Install unknown apps" for the app you used to open it.
- *Apps missing in library*: wait a few seconds after start, then reopen Applications. Some apps do not offer a launch screen.
- *Home button opens the old launcher*: use the default launcher steps above, or reset defaults of the old launcher in Settings → Apps.
- *Start over*: Settings → System → Reset launcher preferences.
